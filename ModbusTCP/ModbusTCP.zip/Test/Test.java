import java.io.*;
import java.net.*;
import java.lang.Thread.*;

public class Test {

  public static void main(String[] args) {

    Socket s = null;
    OutputStream os = null;
    InputStream is = null;
    try {
      s = new Socket("127.0.0.1", 502);
      s.setSoTimeout(2_000);
      os = s.getOutputStream();
      is = s.getInputStream();
      byte[][] osbuf = new byte[][] {
        {0, 0, 0, 0, 0, 6, 0,  1, 0,  0, 0,  1},
        {0, 0, 0, 0, 0, 6, 0,  2, 0,  0, 0,  1},
        {0, 0, 0, 0, 0, 6, 0,  3, 0,  0, 0,  1},
        {0, 0, 0, 0, 0, 6, 0,  4, 0,  0, 0,  1},
        {0, 0, 0, 0, 0, 6, 0,  5, 0, 10, (byte)255, 0},
        {0, 0, 0, 0, 0, 6, 0,  6, 0, 10, 0, 10},
        {0, 0, 0, 0, 0, 8, 0, 15, 0, 20, 0,  1, 1, 1},
        {0, 0, 0, 0, 0, 9, 0, 16, 0, 20, 0,  1, 2, 0, 20}
      };
      byte[] inbuf = new byte[100];
      for (int i = 0; i < osbuf.length; i++) {
        os.write(osbuf[i]);
        if (is.read(inbuf) < 0) throw new Exception();
        Thread.sleep(200);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      if (os != null) try { os.close(); } catch (Exception e) { }
      if (is != null) try { is.close(); } catch (Exception e) { }
      if (s != null && !s.isClosed()) try { s.close(); } catch (Exception e) { }
    }
  }
}
