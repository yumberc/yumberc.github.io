import java.net.*;
import java.util.*;
import java.beans.*;
import java.text.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.print.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.border.*;
import javax.print.*;
import javax.print.attribute.*;
import javax.print.attribute.standard.*;

public class SPreview {

  public static void main(String[] args) {
    new SPreview(args);
  }

  public SPreview(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
      //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      //UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
      //UIManager.setLookAndFeel("com.sun.java.swing.plaf.mac.MacLookAndFeel");
      //UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
      //UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
      //UIManager.setLookAndFeel("com.sun.java.swing.plaf.gtk.GTKLookAndFeel");
      //UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
    } catch (Exception exception) {}

    JFrame frame = new JFrame("Preview");
    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    SPageFormat sPageFormat = new SPageFormat();
    //SPageFormat sPageFormat = new SPageFormat(Size2DSyntax.INCH);

    sPageFormat.fileName = args.length == 1 ? args[0] : "demo.htm";
    sPageFormat.headerSelect = SPageFormat.TEXT;
    sPageFormat.headerText = "File: {0}  Page {1} of {2}";

    //sPageFormat.setPaperSize(200F, 100F, new float[] { 15F, 15F, 15F, 15F }, Size2DSyntax.MM);
    //sPageFormat.mediaSizeName = SPageFormat.USERFORMAT;

    SPreviewPanel sPreviewPanel = new SPreviewPanel(frame, sPageFormat);

    frame.getContentPane().add(sPreviewPanel);

    frame.pack();
    Dimension d = frame.getToolkit().getScreenSize();
    frame.setSize((int)(d.width * 0.7D), (int)(d.height * 0.7D));
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);

  }  // End

  public class SPreviewPanel extends JPanel implements ActionListener, PropertyChangeListener, MouseWheelListener, MouseMotionListener, MouseListener {

    private Window frame;
    private Cursor curNorm, curFlat, curGrab;
    private int dx, dy;
    private JScrollBar hsb, wsb;
    private JScrollPane sp;
    private boolean pressed = false;
    private JButton bPagePrev, bPageNext, bZoomOut, bZoomIn, bPageDialog, bPrintDialog;
    private JLabel lStatusBar;
    private JEditorPane ep;
    private SPrintable sPrintable;
    private SPageFormat sPageFormat;
    private SPrintServiceInfo sPrintServiceInfo;
    private PreviewCanvas canvas;
    private volatile boolean pageValid;

    public SPreviewPanel(Window frame, SPageFormat sPageFormat) {
      this.frame = frame;
      this.sPageFormat = sPageFormat;

      String path = "/res/";
      ImageIcon icPagePrev = new ImageIcon(getClass().getResource(path + "pageprev.png"));
      ImageIcon icPageNext = new ImageIcon(getClass().getResource(path + "pagenext.png"));
      ImageIcon icZoomOut = new ImageIcon(getClass().getResource(path + "zoomout.png"));
      ImageIcon icZoomIn = new ImageIcon(getClass().getResource(path + "zoomin.png"));
      ImageIcon icPageDialog = new ImageIcon(getClass().getResource(path + "pagedialog.png"));
      ImageIcon icPrintDialog = new ImageIcon(getClass().getResource(path + "printdialog.png"));
      Image imFlat = new ImageIcon(getClass().getResource(path + "handflat.png")).getImage();
      Image imGrab = new ImageIcon(getClass().getResource(path + "handgrab.png")).getImage();

      Toolkit tk = Toolkit.getDefaultToolkit();
      curFlat = tk.createCustomCursor(imFlat, new Point(8, 8), "");
      curGrab = tk.createCustomCursor(imGrab, new Point(8, 8), "");

      sPrintable = new SPrintable();

      ep = new JEditorPane("text/html","");

      URL url = getClass().getResource(sPageFormat.fileName);
      //if (url == null) { return; }

      try {
        ep.setPage(url);
      } catch(Exception e) {
        JOptionPane.showMessageDialog(frame, e.getMessage(), "Error message", JOptionPane.ERROR_MESSAGE);
        return;
      }

      pageValid = false;
      ep.addPropertyChangeListener(this);
      while (!pageValid) {
        try { Thread.sleep(100L); } catch(Exception e) {}
      }

      ep.setSize(new Dimension((int)ep.getMinimumSize().getWidth(), Integer.MAX_VALUE));
      ep.setSize(new Dimension((int)ep.getMinimumSize().getWidth(), (int)ep.getPreferredSize().getHeight()));
      sPageFormat.nSize = ep.getMinimumSize();

      JPanel buttonPanel = new JPanel();
      buttonPanel.setBorder(BorderFactory.createEtchedBorder());
      buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
      bPagePrev = new JButton(icPagePrev); bPagePrev.addActionListener(this);
      bPageNext = new JButton(icPageNext); bPageNext.addActionListener(this);
      bZoomOut = new JButton(icZoomOut); bZoomOut.addActionListener(this);
      bZoomIn = new JButton(icZoomIn); bZoomIn.addActionListener(this);
      bPageDialog = new JButton(icPageDialog); bPageDialog.addActionListener(this);
      bPrintDialog = new JButton(icPrintDialog); bPrintDialog.addActionListener(this);

      buttonPanel.add(bPagePrev);
      buttonPanel.add(bPageNext);
      buttonPanel.add(bZoomOut);
      buttonPanel.add(bZoomIn);
      buttonPanel.add(bPageDialog);
      buttonPanel.add(bPrintDialog);

      JPanel pn = new JPanel();
      pn.setLayout(new GridBagLayout());
      curNorm = pn.getCursor();

      sp = new JScrollPane(pn);
      hsb = sp.getHorizontalScrollBar();
      wsb = sp.getVerticalScrollBar();
      canvas = new PreviewCanvas(sp, sPrintable, sPageFormat);

      pn.add(canvas);

      lStatusBar = new JLabel(statusBarString());
      lStatusBar.setBorder(new EtchedBorder());

      setLayout(new BorderLayout());
      add(buttonPanel, BorderLayout.NORTH);
      add(sp, BorderLayout.CENTER);
      add(lStatusBar, BorderLayout.SOUTH);

      pn.addMouseWheelListener(this);
      canvas.addMouseMotionListener(this);
      canvas.addMouseListener(this);

      calculatePageCount();
      changePage(0);
    }

//PropertyChangeListener
    public void propertyChange(PropertyChangeEvent e) {
      if (e.getPropertyName().equals("page")) {
        pageValid = true;
      }
    }

//ActionListener
    public void actionPerformed(ActionEvent event){
      Object source = event.getSource();
      if (source == bPagePrev) { changePage(-1); }
      else if (source == bPageNext) { changePage(1); }
      else if (source == bZoomOut) { changeScale(-0.1D); }
      else if (source == bZoomIn) { changeScale(0.1D); }
      else if (source == bPageDialog) { pageDialog(); }
      else if (source == bPrintDialog) { printDialog(); }
    }

//MouseWheelListener
    public void mouseWheelMoved(MouseWheelEvent event) {
      changeScale(event.getWheelRotation() < 0 ? -0.05D : 0.05D);
      setCur();
    }

//MouseMotionListener
    public void mouseMoved(MouseEvent event) {}
    public void mouseDragged(MouseEvent event) {
      int x = event.getX() - hsb.getValue();
      int y = event.getY() - wsb.getValue();
      if (dx != x) { hsb.setValue(hsb.getValue() + dx - x); dx = x; }
      if (dy != y) { wsb.setValue(wsb.getValue() + dy - y); dy = y; }
    }

//MouseListener
    public void mouseExited(MouseEvent event) { setCur(); }
    public void mouseEntered(MouseEvent event) { setCur(); }
    public void mouseClicked(MouseEvent event) {}
    public void mouseReleased(MouseEvent event) { pressed = false; setCur(); }
    public void mousePressed(MouseEvent event) {
      dx = event.getX() - hsb.getValue();
      dy = event.getY() - wsb.getValue();
      pressed = true;
      setCur();
    }

    public void pageDialog() {
      if (sPrintServiceInfo == null) sPrintServiceInfo = new SPrintServiceInfo();
      if (sPrintServiceInfo.pageDialog(frame, sPageFormat)) {
         calculatePageCount();
         changePage(0);
      }
    }

    public void printDialog() {
      if (sPrintServiceInfo == null) sPrintServiceInfo = new SPrintServiceInfo();
      if (sPrintServiceInfo.printDialog(frame, sPrintable, sPageFormat)) {
         changePage(0);
      }
    }

    public void setCur() {
      if (hsb.isVisible() || wsb.isVisible()) {
        if (pressed) canvas.setCursor(curGrab);
        else canvas.setCursor(curFlat);
      }
      else canvas.setCursor(curNorm);
    }

    public void changeScale(double n) {
      canvas.changeScale(n);
      bZoomOut.setEnabled(Math.round(canvas.getCurrentScale() * 100D) > PreviewCanvas.MINSCALE * 100D);
      bZoomIn.setEnabled(Math.round(canvas.getCurrentScale() * 100D) < PreviewCanvas.MAXSCALE * 100D);
    }

    public void changePage(int n) {
      canvas.changePage(n);
      bPagePrev.setEnabled(canvas.getCurrentPage() > 0);
      bPageNext.setEnabled(canvas.getCurrentPage() < sPageFormat.pageCount - 1);
      bPrintDialog.setEnabled(sPageFormat.pageCount > 0);
      lStatusBar.setText(statusBarString());
    }

    public void calculatePageCount() {
      sPrintable.setPrintable(ep.getPrintable(null, null));
      Graphics g = (new BufferedImage(2, 2, BufferedImage.TYPE_INT_RGB)).createGraphics();
      int pageCount = 0;
      try {
        while (sPrintable.print(g, sPageFormat, pageCount) == Printable.PAGE_EXISTS) pageCount++;
      } catch (Exception e) {}
      g.dispose();
      sPageFormat.pageCount = pageCount;
    }

    public String statusBarString() {
      double s = sPrintable.getDefScale();
      return "Page " + Integer.toString(sPageFormat.pageCount > 0 ? canvas.getCurrentPage() + 1 : 0) + " of " + Integer.toString(sPageFormat.pageCount) +
        (s != 1D ? "  (Scale: " + Integer.toString((int)(s * 100D)) + "%)" : "");
    }

    private static final long serialVersionUID = 1L;

  }  // End SPreviewPanel


  class PreviewCanvas extends Component {

    public static final double MINSCALE = 0.05D, MAXSCALE = 5D;
    private BufferedImage bi;
    private int currentPage = 0;
    private double currentScale = 1.0D;
    private JScrollPane sp;
    private SPrintable sPrintable;
    private SPageFormat sPageFormat;
    private boolean isScale = false;

    public PreviewCanvas(JScrollPane sp, SPrintable sPrintable, SPageFormat sPageFormat) {
      super();
      this.sp = sp;
      this.sPrintable = sPrintable;
      this.sPageFormat = sPageFormat;
    }

    public Dimension getPreferredSize() {
      if (isScale) return new Dimension((int)(sPageFormat.getWidth() * currentScale), (int)(sPageFormat.getHeight() * currentScale));
      else return new Dimension(sp.getViewport().getWidth(), sp.getViewport().getHeight());
    }

    public Dimension getMinimumSize() { return getPreferredSize(); }  

    public void paint(Graphics g) {
      super.paint(g);

      if (!isScale) {
        isScale = true;
        currentScale = Math.min((double)sp.getViewport().getWidth() / sPageFormat.getWidth(), (double)sp.getViewport().getHeight() / sPageFormat.getHeight());
        revalidate();
        return;
      }

      Graphics2D g2 = (Graphics2D) g;

      Rectangle2D page = new Rectangle2D.Double(0, 0, (int)(sPageFormat.getWidth() * currentScale) - 1, (int)(sPageFormat.getHeight() * currentScale) - 1);
      g2.setColor(Color.WHITE);
      g2.fill(page);
      g2.setColor(Color.BLACK);
      g2.draw(page);

      g2.drawImage(bi, 1, 1, (int)(sPageFormat.getWidth() * currentScale) - 2, (int)(sPageFormat.getHeight() * currentScale) - 2, null);

      g2.setStroke(new BasicStroke(1, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER, 2, new float[] { 2, 10 }, 0));
      g2.setColor(Color.BLACK);
      g2.drawRect((int)(sPageFormat.getImageableX() * currentScale) - 2, (int)(sPageFormat.getImageableY() * currentScale) - 2, (int)(sPageFormat.getImageableWidth() * currentScale) + 4, (int)(sPageFormat.getImageableHeight() * currentScale) + 4);
    }

    public void changePage(int n) {

      final double sc = 1.0D;  // quality
      int oldPage = currentPage;
      currentPage = Math.max(0, Math.min(currentPage + n, sPageFormat.pageCount - 1));
      if (n == 0 || oldPage != currentPage) {

        bi = new BufferedImage((int)(sPageFormat.getWidth() * sc), (int)(sPageFormat.getHeight() * sc), BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = bi.createGraphics();
        g2.setColor(Color.WHITE);
        g2.fillRect(0, 0, bi.getWidth(null), bi.getHeight(null));
        g2.scale(sc, sc);
        try {
          if (sPageFormat.pageCount > 0) sPrintable.print(g2, sPageFormat, currentPage);
        } catch (PrinterException exception) {}
        g2.dispose();

        revalidate();
        repaint();
      }
    }

    public void changeScale(double n) {
      double oldScale = currentScale;
      currentScale = Math.max(MINSCALE, Math.min(currentScale + n, MAXSCALE));
      if (oldScale != currentScale) {
        revalidate();
        //repaint();
      }
    }

    public double getCurrentScale() { return currentScale; }
    public int getCurrentPage() { return currentPage; }

    private static final long serialVersionUID = 1L;

  }  // End PreviewCanvas

  class SPageFormat extends PageFormat {

    public static final int LEFT = 0, CENTER = 1, RIGHT = 2;
    public static final int ACTUAL = 0, VALUE = 1, FITWIDTH = 2, FITPAGE = 3;
    public static final int NONE = 0, NUMBER = 1, NUMBERCOUNT = 2, TEXT = 3;
    public static final String USERFORMAT = "User format";

    String fileName = "";
    String printServiceName = "";
    String mediaSizeName = "";
    //String mediaTrayName = "";
    int scaleSelect = ACTUAL;
    int scaleValue = 100;
    boolean centerH = false;
    boolean centerV = false;
    int headerSelect = NONE;
    int footerSelect = NONE;
    int headerAlign = CENTER;
    int footerAlign = CENTER;
    String headerText = "";
    String footerText = "";
    int pageCount = 0;
    boolean color = false;
    Dimension nSize;
    protected int[] margins = new int[4];
    protected int sizeX, sizeY, units;

    public SPageFormat() { this(Size2DSyntax.MM); }

    public SPageFormat(int units) {
      super();
      this.units = units;
      if (units == Size2DSyntax.MM) setPaperSize(210F, 297F, new float[] { 20F, 20F, 20F, 20F }, Size2DSyntax.MM);
      else setPaperSize(8.5F, 11.0F, new float[] { 1F, 1F, 1F, 1F }, Size2DSyntax.INCH);
    }

    public void setPaperSize(float lSizeX, float lSizeY, float[] lMargins, int lUnits) {
      if (lSizeX > lSizeY) { float t = lSizeX; lSizeX = lSizeY; lSizeY = t; setOrientation(LANDSCAPE); };
      double k =  72D * lUnits / Size2DSyntax.INCH;
      Paper paper = new Paper();
      paper.setSize(lSizeX * k, lSizeY * k);
      paper.setImageableArea(lMargins[1] * k, lMargins[0] * k, (lSizeX - lMargins[1] - lMargins[3]) * k, (lSizeY - lMargins[0] - lMargins[2]) * k);
      setPaper(paper);
      margins = new int[] { (int)(lMargins[0] * lUnits), (int)(lMargins[1] * lUnits), (int)(lMargins[2] * lUnits), (int)(lMargins[3] * lUnits) };
      sizeX = (int)(lSizeX * lUnits);
      sizeY = (int)(lSizeY * lUnits);
    }

    public int getUnits() { return units; }
    public String getUnitsDes() { return (units == Size2DSyntax.MM ? "mm" : (units == Size2DSyntax.INCH ? "Inch": "")); }
    public float getX(int units) { return (float)sizeX / (float)units; }
    public float getY(int units) { return (float)sizeY / (float)units; }
    public float[] getMargins(int units) { return new float[] { (float)margins[0] / (float)units, (float)margins[1] / (float)units, (float)margins[2] / (float)units, (float)margins[3] / (float)units }; }

  }  // End scalePageFormat

  public class SPrintable implements Printable {

    private Printable printable;
    private double defScale = 1D;

    public int print(Graphics g, PageFormat pf, int page) throws PrinterException {
      Graphics2D g2 = (Graphics2D) g;
      SPageFormat spf = (SPageFormat) pf;
      double defWidth, defHeight;

      double nWidth = spf.nSize.getWidth();
      double nHeight = spf.nSize.getHeight();

      double xoff = spf.getImageableX();
      double yoff = spf.getImageableY();
      double imageableWidth = spf.getImageableWidth();
      double imageableHeight = spf.getImageableHeight();

      g.setClip((int)xoff, (int)yoff, (int)imageableWidth + 1, (int)imageableHeight + 1);
      g.setColor(Color.BLACK);

      int x, y;
      String text;
      int[] mSelect = { spf.headerSelect, spf.footerSelect };
      int[] mAlign = { spf.headerAlign, spf.footerAlign };
      String[] mText = { spf.headerText, spf.footerText };
      //g.setFont(new Font(g.getFont().getName(), Font.PLAIN, 8));
      FontMetrics fm = g.getFontMetrics();
      for (int i = 0; i < 2; i++) {
        if (mSelect[i] != SPageFormat.NONE) {
          if (i == 0) { yoff += fm.getHeight(); y = fm.getHeight(); }
          else y = (int)pf.getImageableHeight();
          imageableHeight -= fm.getHeight();
          if (mSelect[i] == SPageFormat.NUMBER) text = "{1}";
          else if (mSelect[i] == SPageFormat.NUMBERCOUNT) text = "{1}/{2}";
          else text = mText[i];
          MessageFormat mf = new MessageFormat(text);
          text = mf.format( new Object[] { spf.fileName, Integer.toString(page + 1), Integer.toString(spf.pageCount) });
          x = mAlign[i] == SPageFormat.LEFT ? 0 : Math.max(0, (int)imageableWidth - fm.stringWidth(text));
          if (mAlign[i] == SPageFormat.CENTER) x /= 2;
          g.drawString(text, (int)pf.getImageableX() + x, (int)pf.getImageableY() + y - fm.getDescent());
        }
      }
      if (spf.scaleSelect == SPageFormat.ACTUAL || spf.scaleSelect == SPageFormat.VALUE) {
        defScale = spf.scaleSelect == SPageFormat.VALUE ? spf.scaleValue / 100D : 1.0D;
        defWidth = Math.min(nWidth, imageableWidth / defScale);
        defHeight = imageableHeight / defScale;
      }
      else if (spf.scaleSelect == SPageFormat.FITWIDTH) {
        defScale = Math.min(1, imageableWidth / nWidth);
        defWidth = nWidth;
        defHeight = imageableHeight / defScale;
      }
      else {
        defScale = Math.min(1, Math.min(imageableWidth / nWidth, imageableHeight / nHeight));
        defWidth = nWidth;
        defHeight = imageableHeight / defScale + 50D;
      }
      if (spf.centerH) xoff += Math.max(0D, (imageableWidth - nWidth * defScale) / 2D);
      if (spf.centerV) {
        double ys = Math.max(0D, (imageableHeight - nHeight * defScale) / 2D);
        yoff += ys; defHeight = defHeight - ys / defScale;
      }
      g2.translate(xoff, yoff);
      g2.scale(defScale, defScale);

      PageFormat customPageFormat = new PageFormat();
      Paper paper = new Paper();
      paper.setSize(defWidth, defHeight);
      paper.setImageableArea(0, 0, defWidth, defHeight);
      customPageFormat.setOrientation(PageFormat.PORTRAIT);
      customPageFormat.setPaper(paper);

      return printable.print(g2, customPageFormat, page);
    }

    public void setPrintable(Printable printable) { this.printable = printable; }
    public double getDefScale() { return defScale; }

  } // End SPrintable

  public class SPrintServiceInfo implements ActionListener {
    private boolean ret = false;
    private Window owner;
    private int orientation;
    private int scaleSelect;
    private String[] selectItems = { "None", "Number", "Number/Count", "Text" };
    private String[] alignItems = { "Left", "Center", "Right" };
    private SPageFormat sPageFormat;
    private SPrintable sPrintable;
    private JButton bPgCancel, bPrCancel, bOk, bPrint;
    private JSpinner spMarginLeft, spMarginRight, spMarginTop, spMarginBottom, spCopies;
    private JRadioButton rPortrait, rLandscape, rReverseLandscape;
    private JRadioButton rActual, rValue, rFitWidth, rFitPage;
    private JRadioButton rRangeAll, rRangePages, rMonochrome, rColor;
    private JCheckBox cbScaleCenterH, cbScaleCenterV;
    private JCheckBox cbCollate;
    private JComboBox<String> bPrintService, bMediaSize, bHeaderSelect, bHeaderAlign, bFooterSelect, bFooterAlign, bPrintServiceP;
    private JTextField tHeaderText, tFooterText;
    private JLabel lMediaSize, lPrintServiceP, lIcon;
    private ArrayList<PrintService> printServiceList = new ArrayList<PrintService>();
    private int defaultPrintServiceIndex = -1;
    private ArrayList<MediaSize> mediaSizeList = new ArrayList<MediaSize>();
    private ArrayList<MediaSizeName> mediaSizeNameList = new ArrayList<MediaSizeName>();
    private int defaultMediaSizeIndex = -1;
    private int cpsIndex;
    private float mediaSizeX, mediaSizeY;
    private JFormattedTextField flScaleField, flFromPage, flToPage;
    private JDialog pgDialog, prDialog;

    public boolean pageDialog(Window owner, SPageFormat sPageFormat) {
      this.owner = owner;
      this.sPageFormat = sPageFormat;
      orientation = sPageFormat.getOrientation();
      mediaSizeX = sPageFormat.getX(sPageFormat.getUnits());
      mediaSizeY = sPageFormat.getY(sPageFormat.getUnits());

      pgDialog = new JDialog(owner);
      pgDialog.setTitle("Page setup");
      pgDialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
      pgDialog.setModal(true);
      pgDialog.getContentPane().setLayout(new BorderLayout());

      JPanel mediaPanel = new JPanel(new GridBagLayout());
      mediaPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Media"));

      cpsIndex = -1;
      bPrintService = new JComboBox<String>(); bPrintService.addActionListener(this);
      bMediaSize = new JComboBox<String>(); bMediaSize.addActionListener(this);
      lMediaSize = new JLabel("-");
      lMediaSize.setHorizontalTextPosition(JLabel.LEFT);
      lMediaSize.setVerticalTextPosition(JLabel.CENTER);

      updatePrintServiceInfo();
      int printServiceIndex = defaultPrintServiceIndex;
      if (printServiceList.size() > 0) {
        int it = -1;
        for (int i = 0; i < printServiceList.size(); i++) {
          String psName = printServiceList.get(i).getName();
          bPrintService.addItem(psName);
          if (psName.equals(sPageFormat.printServiceName)) it = i;
        }
        if (it > -1) printServiceIndex = it;
        bPrintService.setSelectedIndex(printServiceIndex);
      }
      else { bPrintService.setEnabled(false); bMediaSize.setEnabled(false); }

      setMediaSizeInfo();

      mediaPanel.add(new JLabel("Print service:"), new GridBagConstraints(0,0, 1,1, 0,0, GridBagConstraints.EAST, 0, new Insets(4, 4, 0, 4), 0,0));
      mediaPanel.add(bPrintService, new GridBagConstraints(1,0, 1,1, 1D,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(4, 0, 0, 4), 0,0));
      mediaPanel.add(new JLabel("Size:"), new GridBagConstraints(0,1, 1,1, 0,0, GridBagConstraints.EAST, 0, new Insets(4, 4, 0, 4), 0,0));
      mediaPanel.add(bMediaSize, new GridBagConstraints(1,1, 1,1, 1D,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(4, 0, 0, 4), 0,0));
      mediaPanel.add(lMediaSize, new GridBagConstraints(1,2, 1,1, 1D,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(4, 0, 4, 4), 0,0));

      JPanel scalePanel = new JPanel(new GridBagLayout());
      scalePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Scaling"));
      ButtonGroup scaleGroup = new ButtonGroup();
      rActual = new JRadioButton("Actual size"); rActual.addActionListener(this);
      rValue = new JRadioButton("Custom size:"); rValue.addActionListener(this);
      rFitWidth = new JRadioButton("Shrink to width"); rFitWidth.addActionListener(this);
      rFitPage = new JRadioButton("Shrink to fit page"); rFitPage.addActionListener(this);
      scaleSelect = sPageFormat.scaleSelect;
      rActual.setSelected(scaleSelect == SPageFormat.ACTUAL);
      rValue.setSelected(scaleSelect == SPageFormat.VALUE);
      rFitWidth.setSelected(scaleSelect == SPageFormat.FITWIDTH);
      rFitPage.setSelected(scaleSelect == SPageFormat.FITPAGE);

      scaleGroup.add(rActual);
      scaleGroup.add(rValue);
      scaleGroup.add(rFitWidth);
      scaleGroup.add(rFitPage);

      flScaleField = sTextField(1, 500);
      flScaleField.setValue(sPageFormat.scaleValue);
      flScaleField.setEnabled(scaleSelect == SPageFormat.VALUE);

      cbScaleCenterH = new JCheckBox("Centered horizontally");
      cbScaleCenterV = new JCheckBox("Centered vertically");
      cbScaleCenterH.setSelected(sPageFormat.centerH);
      cbScaleCenterV.setSelected(sPageFormat.centerV);

      scalePanel.add(rActual, new GridBagConstraints(0,0, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 0), 0,0));
      scalePanel.add(rValue, new GridBagConstraints(0,1, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 0), 0,0));
      scalePanel.add(rFitWidth, new GridBagConstraints(0,2, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 0), 0,0));
      scalePanel.add(rFitPage, new GridBagConstraints(0,3, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 4, 0), 0,0));

      scalePanel.add(flScaleField, new GridBagConstraints(1,0, 1,3, 0,0, GridBagConstraints.WEST, 0, new Insets(0, 0, 0, 0), 0,0));
      scalePanel.add(new JLabel("%"), new GridBagConstraints(2,0, 1,3, 0,0, GridBagConstraints.WEST, 0, new Insets(0, 4, 0, 0), 0,0));

      scalePanel.add(cbScaleCenterH, new GridBagConstraints(3,2, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(0, 0, 0, 4), 0,0));
      scalePanel.add(cbScaleCenterV, new GridBagConstraints(3,3, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(0, 0, 0, 4), 0,0));

      JPanel orientationPanel = new JPanel();
      orientationPanel.setLayout(new GridBagLayout());
      orientationPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Orientation"));
      ButtonGroup orientationGroup = new ButtonGroup();
      rPortrait = new JRadioButton("Portrait"); rPortrait.addActionListener(this);
      rLandscape = new JRadioButton("Landscape"); rLandscape.addActionListener(this);
      rReverseLandscape = new JRadioButton("Reverse Landscape"); rReverseLandscape.addActionListener(this);
      orientation = sPageFormat.getOrientation();
      rPortrait.setSelected(orientation == PageFormat.PORTRAIT);
      rLandscape.setSelected(orientation == PageFormat.LANDSCAPE);
      rReverseLandscape.setSelected(orientation == PageFormat.REVERSE_LANDSCAPE);
      orientationGroup.add(rPortrait);
      orientationGroup.add(rLandscape);
      orientationGroup.add(rReverseLandscape);
      orientationPanel.add(rPortrait, new GridBagConstraints(0,1, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 4), 0,0));
      orientationPanel.add(rLandscape, new GridBagConstraints(0,2, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 4), 0,0));
      orientationPanel.add(rReverseLandscape, new GridBagConstraints(0,3, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 4), 0,0));
      orientationPanel.add(new Container(), new GridBagConstraints(0,4, 1,1, 0,1D, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));

      JPanel marginPanel = new JPanel(new GridBagLayout());
      marginPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Margins ("+sPageFormat.getUnitsDes()+")"));

      spMarginLeft = sSpinner();
      spMarginRight = sSpinner();
      spMarginTop = sSpinner();
      spMarginBottom = sSpinner();
      setMargins(sPageFormat.getMargins(sPageFormat.getUnits()), orientation);

      lIcon = new JLabel(createPaperIcon(orientation));

      marginPanel.add(spMarginTop, new GridBagConstraints(1,0, 1,1, 0,0, GridBagConstraints.CENTER, 0, new Insets(0, 0, 4, 0), 0,0));
      marginPanel.add(spMarginLeft, new GridBagConstraints(0,1, 1,1, 0,0, GridBagConstraints.CENTER, 0, new Insets(0, 0, 0, 0), 0,0));
      marginPanel.add(lIcon, new GridBagConstraints(1,1, 1,1, 0,0, GridBagConstraints.CENTER, 0, new Insets(0, 0, 0, 0), 0,0));
      marginPanel.add(spMarginRight, new GridBagConstraints(2,1, 1,1, 0,0, GridBagConstraints.CENTER, 0, new Insets(0, 0, 0, 0), 0,0));
      marginPanel.add(spMarginBottom, new GridBagConstraints(1,2, 1,1, 0,0, GridBagConstraints.CENTER, 0, new Insets(4, 0, 0, 0), 0,0));

      JPanel headerPanel = new JPanel(new GridBagLayout());
      JPanel footerPanel = new JPanel(new GridBagLayout());
      headerPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Header"));
      footerPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Footer"));

      bHeaderSelect = new JComboBox<String>(selectItems); bHeaderSelect.addActionListener(this);
      bFooterSelect = new JComboBox<String>(selectItems); bFooterSelect.addActionListener(this);
      bHeaderAlign = new JComboBox<String>(alignItems); bHeaderAlign.addActionListener(this);
      bFooterAlign = new JComboBox<String>(alignItems); bFooterAlign.addActionListener(this);
      tHeaderText = new JTextField(sPageFormat.headerText);
      tFooterText = new JTextField(sPageFormat.footerText);

      Dimension dt = new Dimension((int)(bHeaderSelect.getPreferredSize().getWidth() + bHeaderAlign.getPreferredSize().getWidth() + 6), (int)(tHeaderText.getPreferredSize().getHeight()));
      tHeaderText.setPreferredSize(dt);
      tFooterText.setPreferredSize(dt);

      bHeaderSelect.setSelectedIndex(sPageFormat.headerSelect);
      bFooterSelect.setSelectedIndex(sPageFormat.footerSelect);
      bHeaderAlign.setSelectedIndex(sPageFormat.headerAlign);
      bFooterAlign.setSelectedIndex(sPageFormat.footerAlign);

      headerPanel.add(bHeaderSelect, new GridBagConstraints(0,0, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 4), 0,0));
      headerPanel.add(bHeaderAlign, new GridBagConstraints(1,0, 1,1, 1D,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(4, 0, 0, 4), 0,0));
      headerPanel.add(tHeaderText, new GridBagConstraints(0,1, 2,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 4, 4), 0,0));

      footerPanel.add(bFooterSelect, new GridBagConstraints(0,0, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 4), 0,0));
      footerPanel.add(bFooterAlign, new GridBagConstraints(1,0, 1,1, 1D,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(4, 0, 0, 4), 0,0));
      footerPanel.add(tFooterText, new GridBagConstraints(0,1, 2,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 4, 4), 0,0));

      JPanel headerfooterPanel = new JPanel(new GridBagLayout());
      headerfooterPanel.add(headerPanel);
      headerfooterPanel.add(footerPanel);

      JPanel centralPanel = new JPanel();
      centralPanel.setLayout(new GridBagLayout());

      centralPanel.add(mediaPanel, new GridBagConstraints(0,0, 2,1, 0,0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));
      centralPanel.add(scalePanel, new GridBagConstraints(0,1, 2,1, 0,0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));
      centralPanel.add(orientationPanel, new GridBagConstraints(0,2, 1,1, 0,0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));
      centralPanel.add(marginPanel, new GridBagConstraints(1,2, 1,1, 0,0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));
      centralPanel.add(headerfooterPanel, new GridBagConstraints(0,3, 2,1, 0,0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));

      pgDialog.getContentPane().add(centralPanel, BorderLayout.CENTER);

      JPanel buttonPanel = new JPanel(new FlowLayout(4));
      bPgCancel = new JButton("Cancel"); bPgCancel.addActionListener(this);
      buttonPanel.add(bPgCancel);
      bOk = new JButton("Ok"); bOk.addActionListener(this);
      buttonPanel.add(bOk);
      pgDialog.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
      pgDialog.getRootPane().setDefaultButton(bOk);
      pgDialog.pack();
      pgDialog.setResizable(false);
      pgDialog.setLocationRelativeTo(null);
      pgDialog.setVisible(true);

      return ret;
    }

//ActionListener
    public void actionPerformed(ActionEvent actionEvent) {
      Object source = actionEvent.getSource();
      if (source == bOk) { if (pgSave()) { ret = true; pgDialog.dispose(); } }
      else if (source == bPgCancel) { pgDialog.dispose(); }

      if (source == bPrint) { prSave(); prDialog.dispose(); print(); }
      else if (source == bPrCancel) { prDialog.dispose(); }

      else if (source == bPrintService) { completeMediaInfo(); }
      else if (source == bMediaSize) { setMedia();}

      else if (source == rActual) { changeScaleSelect(SPageFormat.ACTUAL); }
      else if (source == rValue) { changeScaleSelect(SPageFormat.VALUE); }
      else if (source == rFitWidth) { changeScaleSelect(SPageFormat.FITWIDTH); }
      else if (source == rFitPage) { changeScaleSelect(SPageFormat.FITPAGE); }

      else if (source == rPortrait) { changeOrientation(PageFormat.PORTRAIT); }
      else if (source == rLandscape) { changeOrientation(PageFormat.LANDSCAPE); }
      else if (source == rReverseLandscape) { changeOrientation(PageFormat.REVERSE_LANDSCAPE); }

      else if (source == bHeaderSelect || source == bFooterSelect) { changeHF(); }

      else if (source == rRangeAll || source == rRangePages) { changeRange(); }

      else if (source == bPrintServiceP) { completePrintServiceInfo(); }

      //else if (source == cbCollate) {}
    }

    public boolean pgSave() {
      float[] margins = getMargins(orientation);
      if (margins[1] + margins[3] >= mediaSizeX || margins[0] + margins[2] >= mediaSizeY) {
          JOptionPane.showMessageDialog(pgDialog, "Page margins are blocked!", "Error message", JOptionPane.ERROR_MESSAGE);
        return false;
      }

      if (bPrintService.getItemCount() > 0) sPageFormat.printServiceName = bPrintService.getSelectedItem().toString();
      if (bMediaSize.getItemCount() > 0) sPageFormat.mediaSizeName = bMediaSize.getSelectedItem().toString();

      sPageFormat.scaleSelect = scaleSelect;
      sPageFormat.scaleValue = (int)flScaleField.getValue();
      sPageFormat.centerH = cbScaleCenterH.isSelected();
      sPageFormat.centerV = cbScaleCenterV.isSelected();

      sPageFormat.headerSelect = bHeaderSelect.getSelectedIndex();
      sPageFormat.headerAlign = bHeaderAlign.getSelectedIndex();
      sPageFormat.headerText = tHeaderText.getText();
      sPageFormat.footerSelect = bFooterSelect.getSelectedIndex();
      sPageFormat.footerAlign = bFooterAlign.getSelectedIndex();
      sPageFormat.footerText = tFooterText.getText();

      margins = getMargins(orientation);
      sPageFormat.setPaperSize(mediaSizeX, mediaSizeY, margins, sPageFormat.getUnits());
      sPageFormat.setOrientation(orientation);
      return true;
    }

    public void changeOrientation(int newOrientation) {
      setMargins(getMargins(orientation), newOrientation);
      lIcon.setIcon(createPaperIcon(newOrientation));
      orientation = newOrientation;
    }

    public void changeScaleSelect(int newScaleSelect) {
      flScaleField.setEnabled(newScaleSelect == SPageFormat.VALUE);
      scaleSelect = newScaleSelect;
    }

    public void changeHF() {
      tHeaderText.setEnabled(bHeaderSelect.getSelectedIndex() == SPageFormat.TEXT);
      bHeaderAlign.setEnabled(bHeaderSelect.getSelectedIndex() != SPageFormat.NONE);

      tFooterText.setEnabled(bFooterSelect.getSelectedIndex() == SPageFormat.TEXT);
      bFooterAlign.setEnabled(bFooterSelect.getSelectedIndex() != SPageFormat.NONE);
    }

    public float[] getMargins(int orientation) {
      float[] margins = new float[4];
      float t, l, b, r;
      t = ((SpinnerNumberModel)spMarginTop.getModel()).getNumber().floatValue();
      l = ((SpinnerNumberModel)spMarginLeft.getModel()).getNumber().floatValue();
      b = ((SpinnerNumberModel)spMarginBottom.getModel()).getNumber().floatValue();
      r = ((SpinnerNumberModel)spMarginRight.getModel()).getNumber().floatValue();
      if (orientation == PageFormat.PORTRAIT) {
        margins[0] = t; margins[1] = l; margins[2] = b; margins[3] = r;
      } else if (orientation == PageFormat.LANDSCAPE) {
        margins[1] = t; margins[2] = l; margins[3] = b; margins[0] = r;
      } else if (orientation == PageFormat.REVERSE_LANDSCAPE) {
        margins[3] = t; margins[0] = l; margins[1] = b; margins[2] = r;
      }
      return margins;
    }

    public void setMargins(float[] margins, int orientation) {
      float t = 0, l = 0, b = 0, r = 0;
      if (orientation == PageFormat.PORTRAIT) {
        t = margins[0]; l = margins[1]; b = margins[2]; r = margins[3];
      } else if (orientation == PageFormat.LANDSCAPE) {
        t = margins[1]; l = margins[2]; b = margins[3]; r = margins[0];
      } else if (orientation == PageFormat.REVERSE_LANDSCAPE) {
        t = margins[3]; l = margins[0]; b = margins[1]; r = margins[2];
      }
      spMarginTop.setValue(t);
      spMarginLeft.setValue(l);
      spMarginBottom.setValue(b);
      spMarginRight.setValue(r);
    }

    public void completeMediaInfo() {
      if (bPrintService.getSelectedIndex() < 0 || cpsIndex == bPrintService.getSelectedIndex()) return;
      cpsIndex = bPrintService.getSelectedIndex();
      PrintService printService = printServiceList.get(cpsIndex);
      updateMediaInfo(printService);
      bMediaSize.removeAllItems();
      int it1 = -1, it2 = -1, it3 = -1, mediaSizeIndex = defaultMediaSizeIndex;
      for (int i = 0; i < mediaSizeList.size(); i++) {
        MediaSizeName mediaSizeName = mediaSizeNameList.get(i);
        MediaSize mediaSize = mediaSizeList.get(i);
        String msName = ((Media)mediaSizeName).toString();
        bMediaSize.addItem(msName);
        if (msName.equals(sPageFormat.mediaSizeName)) it1 = i;
        if (mediaSize.getX(1) == sPageFormat.getX(1) && mediaSize.getY(1) == sPageFormat.getY(1)) it2 = i;
        if (mediaSizeIndex == i && it2 == i) it3 = i;
      }
      if (it1 > -1) mediaSizeIndex = it1;
      else if (it3 > -1) mediaSizeIndex = it3;
      else if (it2 > -1) mediaSizeIndex = it2;
      if (it2 == -1) {
        bMediaSize.addItem(SPageFormat.USERFORMAT);
        mediaSizeList.add(new MediaSize(sPageFormat.getX(1), sPageFormat.getY(1), 1));
        if (sPageFormat.mediaSizeName.equals(SPageFormat.USERFORMAT)) mediaSizeIndex = bMediaSize.getItemCount() - 1;
      }
      if (bMediaSize.getItemCount() > 0) {
        bMediaSize.setSelectedIndex(mediaSizeIndex);
        bMediaSize.setEnabled(true);
      } else bMediaSize.setEnabled(false);
    }

    public void setMedia() {
      int i = bMediaSize.getSelectedIndex();
      if (mediaSizeList.size() > 0 && i >= 0) {
        MediaSize mediaSize = mediaSizeList.get(i);
        mediaSizeX = mediaSize.getX(sPageFormat.getUnits());
        mediaSizeY = mediaSize.getY(sPageFormat.getUnits());
      }
      setMediaSizeInfo();
    }

    public void setMediaSizeInfo() {
      lMediaSize.setIcon(createWarningIcon(sPageFormat.getX(sPageFormat.getUnits()) != mediaSizeX || sPageFormat.getY(sPageFormat.getUnits()) != mediaSizeY));
      lMediaSize.setText(Float.toString((float)(Math.rint(mediaSizeX * 100F) / 100F)) + " x " + Float.toString((float)(Math.rint(mediaSizeY * 100F) / 100F)) + " (" + sPageFormat.getUnitsDes() + ")");
    }

    public JSpinner sSpinner() {
      int fraction = 2;
      double increment = 0.01D;
      if (sPageFormat.getUnits() == Size2DSyntax.MM) {
        fraction = 0;
        increment = 1D;
      }
      JSpinner spinner = new JSpinner(new SpinnerNumberModel(0.0D, 0.0D, 500.0D, increment));
      JSpinner.NumberEditor editor = (JSpinner.NumberEditor)spinner.getEditor();
      DecimalFormat df = editor.getFormat();
      df.setMinimumIntegerDigits(1);
      df.setMaximumIntegerDigits(3);
      df.setMinimumFractionDigits(fraction);
      df.setMaximumFractionDigits(fraction);
      df.setDecimalSeparatorAlwaysShown(fraction > 0);
      return spinner;
    }

    public JFormattedTextField sTextField(int min, int max) {
      JFormattedTextField formattedTextField;
      DecimalFormat df = new DecimalFormat();
      df.setMinimumIntegerDigits(0);
      df.setMaximumIntegerDigits(3);
      NumberFormatter nf = new NumberFormatter(df);
      nf.setMinimum(min);
      nf.setMaximum(max);
      nf.setAllowsInvalid(true);
      nf.setCommitsOnValidEdit(true);
      formattedTextField = new JFormattedTextField(nf);
      try {
        formattedTextField.setColumns((nf.valueToString(max)).length());
      } catch (ParseException e) {}
      formattedTextField.setHorizontalAlignment(JTextField.RIGHT);
      return formattedTextField;
    }

    public Icon createPaperIcon(int orientation) {
      BufferedImage bi = new BufferedImage(25, 25, BufferedImage.TYPE_INT_ARGB);
      Graphics2D g2 = bi.createGraphics();
      double turn = 0D;
      if (orientation == PageFormat.LANDSCAPE) turn = 90D;
      else if (orientation == PageFormat.REVERSE_LANDSCAPE) turn = 270D;
      g2.rotate(Math.toRadians(turn), bi.getWidth() / 2D, bi.getHeight() / 2D);
      int[] xPoints = { 12, 4,  4, 20, 20, 12, 12, 20 };
      int[] yPoints = {  1, 1, 23, 23,  7,  7,  1,  7 };
      g2.setColor(Color.WHITE);
      g2.fillPolygon(xPoints, yPoints, 8);
      g2.setColor(Color.BLACK);
      g2.drawPolygon(xPoints, yPoints, 8);
      g2.dispose();
      return new ImageIcon(bi);
    }

    public Icon createWarningIcon(boolean b) {
      BufferedImage bi = new BufferedImage(14, 14, BufferedImage.TYPE_INT_ARGB);
      Graphics2D g2 = bi.createGraphics();
      if (b) {
        int[] xPoints = { 5,  0,  1, 10, 11, 6 };
        int[] yPoints = { 0, 10, 11, 11, 10, 0 };
        g2.setColor(Color.YELLOW);
        g2.fillPolygon(xPoints, yPoints, 6);
        g2.setColor(Color.RED);
        g2.drawPolygon(xPoints, yPoints, 6);
        g2.fillRect(5, 4, 2, 4);
        g2.fillRect(5, 9, 2, 1);
      }
      g2.dispose();
      return new ImageIcon(bi);
    }

    public boolean printDialog(Window owner, SPrintable sPrintable, SPageFormat sPageFormat) {
      this.owner = owner;
      this.sPrintable = sPrintable;
      this.sPageFormat = sPageFormat;
      if (sPageFormat.pageCount == 0) return false;

      updatePrintServiceInfo();

      if (printServiceList.size() == 0 ) {
        JOptionPane.showMessageDialog(owner, "Printer not found!", "Error message", JOptionPane.ERROR_MESSAGE);
        return false;
      }
      prDialog = new JDialog(owner);
      prDialog.setTitle("Print Setup");
      prDialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
      prDialog.setModal(true);
      prDialog.getContentPane().setLayout(new BorderLayout());

      JPanel printServicePanel = new JPanel(new GridBagLayout());
      printServicePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Print service"));

      bPrintServiceP = new JComboBox<String>();
      lPrintServiceP = new JLabel("-");
      lPrintServiceP.setHorizontalTextPosition(JLabel.LEFT);
      lPrintServiceP.setVerticalTextPosition(JLabel.CENTER);

      int printServiceIndex = defaultPrintServiceIndex;
      int it = -1;
      for (int i = 0; i < printServiceList.size(); i++) {
        String psName = printServiceList.get(i).getName();
        bPrintServiceP.addItem(psName);
        if (psName.equals(sPageFormat.printServiceName)) it = i;
      }
      if (it > -1) printServiceIndex = it;

      printServicePanel.add(new JLabel("Name:"), new GridBagConstraints(0,0, 1,1, 0,0, GridBagConstraints.EAST, 0, new Insets(4, 4, 0, 4), 0,0));
      printServicePanel.add(bPrintServiceP, new GridBagConstraints(1,0, 1,1, 1D,0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(4, 0, 0, 4), 0,0));
      printServicePanel.add(lPrintServiceP, new GridBagConstraints(1,1, 1,1, 1D,0, GridBagConstraints.WEST, 0, new Insets(4, 0, 4, 4), 0,0));

      JPanel rangePanel = new JPanel(new GridBagLayout());
      rangePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Range"));
      ButtonGroup rangeGroup = new ButtonGroup();
      rRangeAll = new JRadioButton("All"); rRangeAll.addActionListener(this);
      rRangePages = new JRadioButton("Pages"); rRangePages.addActionListener(this);
      rRangeAll.setSelected(true);
      rRangePages.setSelected(false);
      flFromPage = sTextField(1, 999);
      flToPage = sTextField(1, 999);
      flFromPage.setValue(1);
      flToPage.setValue(sPageFormat.pageCount);

      rangeGroup.add(rRangeAll);
      rangeGroup.add(rRangePages);
      rangePanel.add(rRangeAll, new GridBagConstraints(0,0, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 0), 0,0));
      rangePanel.add(rRangePages, new GridBagConstraints(0,1, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 0), 0,0));
      rangePanel.add(flFromPage, new GridBagConstraints(1,1, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(0, 4, 0, 4), 0,0));
      rangePanel.add(new JLabel("-"), new GridBagConstraints(2,1, 1,1, 0,0, GridBagConstraints.CENTER, 0, new Insets(0, 0, 0, 0), 0,0));
      rangePanel.add(flToPage, new GridBagConstraints(3,1, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(0, 4, 0, 4), 0,0));
      flFromPage.setEnabled(false);
      flToPage.setEnabled(false);
      if (sPageFormat.pageCount <= 1) {
        rRangeAll.setEnabled(false);
        rRangePages.setEnabled(false);
      }

      JPanel copiesPanel = new JPanel(new GridBagLayout());
      copiesPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Copies"));
      spCopies = new JSpinner(new SpinnerNumberModel(1, 1, 999, 1));
      cbCollate = new JCheckBox("Collate");

      copiesPanel.add(spCopies, new GridBagConstraints(0,0, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 4), 0,0));
      copiesPanel.add(cbCollate, new GridBagConstraints(0,1, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 4, 4), 0,0));

      JPanel appearancePanel = new JPanel(new GridBagLayout());
      appearancePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Appearance"));
      ButtonGroup appearanceGroup = new ButtonGroup();
      rMonochrome = new JRadioButton("Monochrome"); rMonochrome.addActionListener(this);
      rColor = new JRadioButton("Color"); rColor.addActionListener(this);
      rMonochrome.setSelected(!sPageFormat.color);
      rColor.setSelected(sPageFormat.color);
      appearanceGroup.add(rMonochrome);
      appearanceGroup.add(rColor);
      appearancePanel.add(rMonochrome, new GridBagConstraints(0,0, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 0, 4), 0,0));
      appearancePanel.add(rColor, new GridBagConstraints(0,1, 1,1, 0,0, GridBagConstraints.WEST, 0, new Insets(4, 4, 4, 4), 0,0));
      appearancePanel.add(new Container(), new GridBagConstraints(0,2, 1,1, 0,1D, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));

      JPanel centralPanel = new JPanel();
      centralPanel.setLayout(new GridBagLayout());

      centralPanel.add(printServicePanel, new GridBagConstraints(0,0, 3,1, 0,0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));
      centralPanel.add(rangePanel, new GridBagConstraints(0,1, 1,1, 0,0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));
      centralPanel.add(copiesPanel, new GridBagConstraints(1,1, 1,1, 0,0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));
      centralPanel.add(appearancePanel, new GridBagConstraints(2,1, 1,1, 0,0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0,0));

      prDialog.getContentPane().add(centralPanel, BorderLayout.CENTER);

      bPrintServiceP.addActionListener(this);
      bPrintServiceP.setSelectedIndex(printServiceIndex);

      JPanel buttonPanel = new JPanel(new FlowLayout(4));
      bPrCancel = new JButton("Cancel"); bPrCancel.addActionListener(this);
      buttonPanel.add(bPrCancel);
      bPrint = new JButton("Print"); bPrint.addActionListener(this);
      buttonPanel.add(bPrint);
      prDialog.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
      prDialog.getRootPane().setDefaultButton(bPrint);
      prDialog.pack();
      prDialog.setResizable(false);
      prDialog.setLocationRelativeTo(null);
      prDialog.setVisible(true);

      return false;
    }

    public void changeRange() {
      flFromPage.setEnabled(rRangePages.isSelected());
      flToPage.setEnabled(rRangePages.isSelected());
    }

    public boolean prSave() {
      if (rColor.isEnabled()) sPageFormat.color = rColor.isSelected();
      if (bPrintServiceP.getItemCount() > 0) sPageFormat.printServiceName = bPrintServiceP.getSelectedItem().toString();
      return true;
    }
    
    public void completePrintServiceInfo() {
      if (bPrintServiceP.getSelectedIndex() < 0) return;
      PrintService printService = printServiceList.get(bPrintServiceP.getSelectedIndex());
      String str = "-";
      PrintServiceAttribute psattr;
      psattr = printService.getAttribute(PrinterIsAcceptingJobs.class);
      if (psattr != null) str = (PrinterIsAcceptingJobs)psattr == PrinterIsAcceptingJobs.ACCEPTING_JOBS ? "Ready" : "Not ready";

      psattr = printService.getAttribute(QueuedJobCount.class);
      if (psattr != null && ((QueuedJobCount)psattr).getValue() > 0) str += " ("+Integer.toString(((QueuedJobCount)psattr).getValue())+")";

      psattr = printService.getAttribute(ColorSupported.class);
      boolean bool = (psattr == null || (ColorSupported)psattr == ColorSupported.SUPPORTED);
      rColor.setEnabled(bool);
      rMonochrome.setEnabled(bool);

      updateMediaInfo(printService);
      int maxPaperSizeX = 210000;
      int maxPaperSizeY = 297000;
      for (int i = 0; i < mediaSizeList.size(); i++) {
        MediaSize mediaSize = mediaSizeList.get(i);
        maxPaperSizeX = Math.max(maxPaperSizeX, (int)mediaSize.getX(1));
        maxPaperSizeY = Math.max(maxPaperSizeY, (int)mediaSize.getY(1));
      }
      lPrintServiceP.setIcon(createWarningIcon(sPageFormat.getX(1) > maxPaperSizeX || sPageFormat.getY(1) > maxPaperSizeY));
      lPrintServiceP.setText(str);
    }

    public void updatePrintServiceInfo() {
      printServiceList.clear();
      defaultPrintServiceIndex = -1;
      PrintService defaultPrintService = PrintServiceLookup.lookupDefaultPrintService();
      String dpsName = defaultPrintService == null ? "" : defaultPrintService.getName();
      PrintService[] printServices = PrintServiceLookup.lookupPrintServices(null, null);
      if (printServices.length > 0 ) {
        defaultPrintServiceIndex = 0;
        for (int i = 0; i < printServices.length; i++) {
          printServiceList.add(printServices[i]);
          if (dpsName.equals(printServices[i].getName())) defaultPrintServiceIndex = i;
        }
      } else if (defaultPrintService != null) {
        printServiceList.add(defaultPrintService);
        defaultPrintServiceIndex = 0;
      }
    }

    public void updateMediaInfo(PrintService printService) {
      mediaSizeList.clear();
      mediaSizeNameList.clear();
      defaultMediaSizeIndex = -1;
      String defaulMediaSizeName = "";
      Class<Media> mediaClass = Media.class;
      Object defaulMediaObject = printService.getDefaultAttributeValue(mediaClass);
      if (defaulMediaObject instanceof MediaSizeName) {
        defaulMediaSizeName = ((Media)defaulMediaObject).toString();
      } //else if (defaulMediaObject instanceof MediaTray) {}

      if (printService.isAttributeCategorySupported(mediaClass)) {
        Object object = printService.getSupportedAttributeValues(mediaClass, DocFlavor.SERVICE_FORMATTED.PAGEABLE, null);
        if (object instanceof Media[]) {
          Media[] medias = (Media[])object;
          for (int i = 0; i < medias.length; i++) {
            Object mediaObject = medias[i];
            if (mediaObject instanceof MediaSizeName) {
              MediaSizeName mediaSizeName = (MediaSizeName)mediaObject;
              MediaSize mediaSize = MediaSize.getMediaSizeForName(mediaSizeName);
              if (mediaSize == null) mediaSize = new MediaSize(210F, 297F, Size2DSyntax.MM);
              if (defaulMediaSizeName.equals(((Media)mediaSizeName).toString())) defaultMediaSizeIndex = i;
              mediaSizeList.add(mediaSize);
              mediaSizeNameList.add(mediaSizeName);
            } //else if (mediaObject instanceof MediaTray) {}
          }
        }
      }
      if (mediaSizeNameList.size() > 0 && defaultMediaSizeIndex == -1) defaultMediaSizeIndex = 0;
    }

    public boolean print() {
      ret = true;
      PrintService printService = printServiceList.get(bPrintServiceP.getSelectedIndex());
      PrinterJob printerJob = PrinterJob.getPrinterJob();
      printerJob.setPrintable(sPrintable, sPageFormat);

      PrintRequestAttributeSet attributes = new HashPrintRequestAttributeSet();

      if (rMonochrome.isEnabled() && rMonochrome.isSelected()) attributes.add(Chromaticity.MONOCHROME);

      int copies = Math.max(1, ((SpinnerNumberModel)spCopies.getModel()).getNumber().intValue());
      if (copies > 1) {
        attributes.add(new Copies(copies));
        if (cbCollate.isSelected()) attributes.add(SheetCollate.COLLATED);
        else attributes.add(SheetCollate.UNCOLLATED);
      }

      if (rRangePages.isSelected()){
        int fromPage = Math.max(1, Math.min((int)flFromPage.getValue(), sPageFormat.pageCount));
        int toPage = Math.max(fromPage, Math.min((int)flFromPage.getValue(), sPageFormat.pageCount));
        attributes.add(new PageRanges(fromPage, toPage));
      }

      Cursor cursor = owner.getCursor();
      try {
        printerJob.setPrintService(printService);
        owner.setCursor(new Cursor(Cursor.WAIT_CURSOR));
        printerJob.print(attributes);
      } catch (Exception e) {
        JOptionPane.showMessageDialog(owner, e.toString(), "Error message", JOptionPane.ERROR_MESSAGE);
        ret = false;
      }
      owner.setCursor(cursor);
      return ret;
    }

  } // End SPrintServiceInfo

} // End SPreview
