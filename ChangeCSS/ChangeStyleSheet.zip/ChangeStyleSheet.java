import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import javafx.collections.*;
import java.util.*;

public class ChangeStyleSheet extends Application {

  List<String> urls = new ArrayList<>();
  ChoiceBox<String> cb = new ChoiceBox<>();

  @Override
  public void start(Stage stage) {
    HBox layout = new HBox(10);
    stage.setScene(new Scene(layout, 400, 150));

    Class<?> skinClass = null;
    try {
      skinClass = Class.forName("com.sun.javafx.scene.control.skin.Utils");
    } catch (Exception e) {}

    addItem(null, null, "Default");
    addItem(skinClass, "modena/modena.css", "Modena");
    addItem(skinClass, "caspian/caspian.css", "Caspian");
    addItem(skinClass, "modena/blackOnWhite.css", "Modena-BlackOnWhite");
    addItem(skinClass, "modena/whiteOnBlack.css", "Modena-WhiteOnBlack");
    addItem(skinClass, "modena/yellowOnBlack.css", "Modena-YellowOnBlack");
    addItem(getClass(), "myCss.css", "MyCss");

    cb.getSelectionModel().selectFirst();
    cb.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue) -> {
      String url = urls.get(newValue.intValue());
      if (url == null)
        stage.getScene().getStylesheets().clear();
      else
        stage.getScene().getStylesheets().setAll(url);
    });

    Button button = new Button("Click Me");
    button.setOnAction(event -> {
      Stage newStage = new Stage();
      newStage.initOwner(stage);
      VBox vb = new VBox(10);
      newStage.setScene(new Scene(vb, 200, 200));
      newStage.show();
      vb.getChildren().addAll(new Label("Label"), new TextField("TextField"), /*new Spinner<Integer>(0, 10, 0),*/ new Button("Button"), new CheckBox("CheckBox"), new RadioButton("RadioButton"));
      vb.setAlignment(Pos.CENTER);

      ListChangeListener<String> listener = c -> {
        if (c.next()) {
          System.out.println("ListChangeListener " + c.getList());
          newStage.getScene().getStylesheets().setAll(stage.getScene().getStylesheets());
        }
      };

      stage.getScene().getStylesheets().addListener(listener);

      newStage.setOnCloseRequest(evt -> stage.getScene().getStylesheets().removeListener(listener));

      newStage.getScene().getStylesheets().setAll(stage.getScene().getStylesheets());

    });

    layout.getChildren().addAll(cb, button);
    layout.setAlignment(Pos.CENTER);

    stage.show();
  }
    
  void addItem(Class<?> cl, String name, String desc) {
    try {
      //String url = (name == null ? null : cl.getResource(name).toExternalForm());
      String url = (name == null ? null : cl.getResource("").toExternalForm() + name); // javafx-sdk-11.0.1
      urls.add(url);
      cb.getItems().add(desc);
    } catch (Exception e) {}
  }

}
