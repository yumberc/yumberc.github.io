import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.*;
import javafx.scene.layout.*;
import javafx.collections.*;
import javafx.beans.property.*;

public class VObservableList extends Application {

  @Override
  public void start(Stage stage) {
    BorderPane layout = new BorderPane();
    stage.setScene(new Scene(layout, 700, 400));

    TableView<Integer> tableView = new TableView<>();
    tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

    tableView.setItems(new ObservableListBase<Integer>() {
      Integer value = Integer.valueOf(-1);

      @Override
      public int size() {
        return 1000000;
      }

      @Override
      public Integer get(int index) {
        if (index < 0 || index >= size()) throw new IndexOutOfBoundsException();
        if (index != value.intValue()) {
          value = Integer.valueOf(index);
        }
        return value;
      }
    });

    TableColumn<Integer, String> column = new TableColumn<>("Column");

    column.setCellValueFactory(cellData -> {
      return new ReadOnlyObjectWrapper<String>("Item " + cellData.getValue());
    });

    tableView.getColumns().add(column);
    tableView.getSelectionModel().selectFirst();
    tableView.sortPolicyProperty().set(t -> false);

    layout.setCenter(tableView);
    stage.show();
  }
}