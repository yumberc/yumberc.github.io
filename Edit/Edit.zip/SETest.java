import java.util.*;

import javafx.scene.control.*;
import javafx.beans.property.*;
import javafx.scene.*;
import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.canvas.*;

public class SETest extends Edit.SchemeElement {

  CubicCurve curve;

  public SETest() {
    super();
    curve = new CubicCurve();
    addAllProperty(new Edit.ElementProperty(curve.startXProperty()).setRestr().setEditable(false),
                   new Edit.ElementProperty(curve.startYProperty()).setRestr().setEditable(false),
                   new Edit.ElementProperty(curve.endXProperty()).setRestr().setEditable(false),
                   new Edit.ElementProperty(curve.endYProperty()).setRestr().setEditable(false),
                   new Edit.ElementProperty(curve.controlX1Property()).setRestr().setEditable(false),
                   new Edit.ElementProperty(curve.controlY1Property()).setRestr().setEditable(false),
                   new Edit.ElementProperty(curve.controlX2Property()).setRestr().setEditable(false),
                   new Edit.ElementProperty(curve.controlY2Property()).setRestr().setEditable(false),
                   new Edit.ElementProperty(curve.strokeProperty(), Paint.class),
                   new Edit.ElementProperty(curve.strokeWidthProperty()),
                   new Edit.ElementProperty(curve.strokeLineCapProperty(), StrokeLineCap.class)
    );
    childrenAddAll(curve);
  }

  @Override public void init(double x, double y) {
    curve.startXProperty().set(x);
    curve.startYProperty().set(y + 25);
    curve.endXProperty().set(x + 50);
    curve.endYProperty().set(y + 25);
    curve.controlX1Property().set(x + 25);
    curve.controlY1Property().set(y);
    curve.controlX2Property().set(x + 25);
    curve.controlY2Property().set(y + 50);
    curve.setFill(null);
    curve.setStroke(Color.BLACK);
  }

  @Override public Node[] anchors() {
    return new Node[] {
      createBoundLine(curve.controlX1Property(), curve.controlY1Property(), curve.startXProperty(), curve.startYProperty()),
      createBoundLine(curve.controlX2Property(), curve.controlY2Property(), curve.endXProperty(),   curve.endYProperty()),
      createAnchor(curve.startXProperty(), curve.startYProperty(), true),
      createAnchor(curve.endXProperty(), curve.endYProperty(), true),
      createAnchor(curve.controlX1Property(), curve.controlY1Property(), true),
      createAnchor(curve.controlX2Property(), curve.controlY2Property(), true)
    };
  }

  protected ArrayList<MenuItem> items;
  @Override public ArrayList<MenuItem> getItems() {
    if (items == null) {
      MenuItem mi = new MenuItem("Test");
      mi.setOnAction(ae -> { scheme.alert("x=" + scheme.getCurrentMouseEvent().getX() + " y=" + scheme.getCurrentMouseEvent().getY()); });
      items = new ArrayList<>(Arrays.asList(mi));
    }
    return items;
  }

  @Override public String getDescription() { return "Cubic Curve"; }

  @Override public Node getPicture(double size) {
    double half = size / 2;
    Canvas canvas = new Canvas(size, size);
    GraphicsContext gc = canvas.getGraphicsContext2D();
    gc.setStroke(Color.BLACK);
    gc.strokeLine(half, 0, 0, half);
    gc.strokeLine(size, half, half, size);
    gc.setStroke(Color.BLUE);
    gc.beginPath();
    gc.moveTo(0, half);
    gc.bezierCurveTo(half, 0, half, size, size, half);
    gc.stroke();
    return canvas;
  }

}  //end class SETest
