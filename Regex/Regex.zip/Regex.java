import java.util.regex.*;
import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.web.*;
import javafx.geometry.*;

public class Regex extends Application {

  TextField textField;
  TextArea textArea;
  WebEngine webEngine;
  Pattern pattern;
  StringBuilder sb = new StringBuilder();

  @Override
  public void start(Stage stage) {
    textField = new TextField();
    textArea = new TextArea();

    textField.textProperty().addListener((v, o, n) -> update(true));
    textArea.textProperty().addListener((v, o, n) -> update(false));

    WebView webView = new WebView();
    webEngine = webView.getEngine();
    webEngine.loadContent("<html><head><style>.m{background-color:#F0EEA0;color:red;}</style></head><body></body></html>");
    //webView.setZoom(.77);

    StackPane stackPane = new StackPane(webView);
    stackPane.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
    stackPane.setBorder(new Border(new BorderStroke(Color.web("CECECE"), BorderStrokeStyle.SOLID, new CornerRadii(2), BorderWidths.DEFAULT)));

    Label label1 = new Label("Regex:"), label2 = new Label("Text:"), label3 = new Label("Result:");
    Insets insets = new Insets(2,0,2,9);
    label1.setPadding(insets);
    label2.setPadding(insets);
    label3.setPadding(insets);

    SplitPane splitPane = new SplitPane(new VBox(label2, textArea), new VBox(label3, stackPane));
    splitPane.setOrientation(Orientation.VERTICAL);

    VBox vBox = new VBox(new VBox(label1, textField), splitPane);
    VBox.setVgrow(textArea, Priority.ALWAYS);

    stage.setScene(new Scene(vBox, 300, 300));
    stage.show();

    Platform.runLater(() -> {
      textField.setText("[0-9a-z]*");
      textArea.setText("0123456789\n!\"#$%&\'()*+,-./:;<=>?@[\\]^_{|}\nABCDEFGHIJKLMNOPQRSTUVWXYZ\nabcdefghijklmnopqrstuvwxyz");
    });
  }

  void update(boolean b) {
    if (b) {
      pattern = null;
      try {
        pattern = Pattern.compile(textField.getText());
      } catch (Exception e) { }
    }
    sb.setLength(0);
    if (pattern == null) {
      sb.append("<span style=\"color:Red\">Pattern Error</span>");
    } else {
      String str = textArea.getText();
      Matcher matcher = pattern.matcher(str);
      int pos = 0;
      while (matcher.find()) {
        app(str.substring(pos, matcher.start()));
        sb.append("<span class=\"m\">");
        app(matcher.group());
        sb.append("</span>");
        pos = matcher.end();
      }
      if (pos > 0) app(str.substring(pos));
    }
    webEngine.executeScript("document.body.innerHTML='" + sb.toString() + "'");
  }

  void app(String s) {
    for(int i = 0, len = s.length(); i < len; i++) {
      char ch = s.charAt(i);
      switch (ch) {
        case ' ' : sb.append("&nbsp;"); break;
        case '&' : sb.append("&amp;"); break;
        case '<' : sb.append("&lt;"); break;
        case '>' : sb.append("&gt;"); break;
        //case '\"': sb.append("&quot;"); break;
        case '\'': sb.append("&apos;"); break;
        case '\\': sb.append("&#92;"); break;
        case '\n': sb.append("<br>"); break;
        default  : sb.append(ch);
      }
    }
  }  

}
